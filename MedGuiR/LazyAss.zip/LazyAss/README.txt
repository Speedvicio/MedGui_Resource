This tool is for the ripping of console games, specifically PC-CD, PC-FX, SATURN and in any cases you can convert PSX games.
The same tool should also work with games for SEGA CD and other era cd games, but has not been tested personally.

Final extracted game can be started by any emulators (Mednafen support ogg/mpc/wav and flac format).

* Cfs format can be mounted by Pismo File Mount or by MedGui Reborn Mednafen frontend.
You need anyway to install Pismo File Mount, download it at: 
https://pismotec.com/download/
 

**Small how to:**

To refresh or Eject/Unmount a Cd/Dvd unit, press right mouse button on Cd/Dvd combo list

<< To Convert from a cue/bin (bin2iso/bchunk engine) or from a cue/bin (also Redump multi bin file are allowed), ccd/img/sub or mds/mdf (Disco Hawk engine). >>

    Select a cue, (ccd, mds only by Disco Hawk engine) file by cue/bin button
    -- The tool try to detect the cue type of file from MODE1/2352, MODE2/2352 and MODE1/2048 and the console type CD.
    -- If the value is not recognized, will be select a generic MODE1/2048.
    Set a name for ripped game (no empty values are allowed)
    Select a encode format for extracted audio file
    Select the parameters for final audio encode
    Select the destination path of file extracted and encoded (no empty values are allowed)
    Trim wave flag try to reduce the size of extracted wave file (this task is optional and don't recommended)
    Press start conversion button and wait for the end of task

<< To Dump/Convert from a other virtual cd image or from a physical or virtual cd/dvd drives >>

    Check Drive Letter option (the tool detect all available cd/dvd device and the cue/bin button change to daemon tool icon)
    Mount a virtual cd/dvd image file by your favourite virtual image tool.
    -- If Daemon Tool is installed on your pc you can auto mount a virtual image on the fly.
    -- The tool try to auto detect the version of Daemon Tool installed from lite,pro and ultra or you can select it manually.
    Set a name for ripped game, the tool try to detect the label name from cd/dvd (no empty values are allowed)
    Select the destination path of file extracted and encoded (no empty values are allowed).

<< To only dump >>
5) Check Dump Only option, all other audio section will be disabled
-- If your cd/dvd image or physical support is damaged you can try to check Paranoia option.
-- This option perform overlapped reading to avoid jitter with additional checks of the read audio data

<< To dump and convert >>
5) Select a encode format for extracted audio file and select the parameters for final audio encode.
6) Press start conversion button and wait for the end of task (the operation may take several minutes)

<< To Rebuild a converted cue/iso/"wave" or lossy codec into cue/iso/"wav", "bin" and/or ccd/img/sub format >>

    Select a cue (ripped) file by cue/bin button **
    Set a name for ripped game (no empty values are allowed)
    Select the destination path of file extracted and encoded (no empty values are allowed)
    Check Rebuild ripped CUE option
    Press start conversion button and wait for the end of task
    Select the destination and the file name to save and wait.
    -- All other tasks (2,3,4,5) will be skipped.

** If will be detected a cue/iso/bin/wav, a popup window appear. - The user can select by pressing one of two buttons, if that file will be merged into a ccd/img/sub file or for "Redump file format" also into a single cue/bin file.

<< To compress processed file into zip or cfs format >>

    Tick "Create After Conversion"
    Select Zip or Cfs format
    -- If you select Zip, will be create a zip archive using Net Framework ZipFile class.
    -- If you select Cfs, will be create a compressed Compact File Set.
    You can use standard zip compression LZSS with Huffman coding (less compression but faster) or lzma Large dictionary LZSS with adaptive range coding (better compression but slower).
    --- Pismo button will open ptiso.exe with a GUI, it is helpful to create/convert a alredu processed virtual image into cfs or ciso format.

Note: You can also Dump and convert a audio cd but this operation take several minutes